package StoryWorld.Alive;

public enum Gender {
    MALE, FEMALE
}

package StoryWorld.Alive.Human.Emotions;

public interface ActionsDicreaseMood {
    void cry();
    void upset();
}

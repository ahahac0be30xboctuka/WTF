package StoryWorld.Inanimate;

import StoryWorld.Places.Place;

public class CatBasket extends InanimateObjects {

    public CatBasket(String name) {
        super(name);
    }

    public CatBasket(String name, Place location) {
        super(name, location);
    }
}

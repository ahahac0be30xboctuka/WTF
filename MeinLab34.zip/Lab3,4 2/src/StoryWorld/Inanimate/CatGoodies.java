package StoryWorld.Inanimate;

public class CatGoodies extends InanimateObjects {

    public CatGoodies(String name) {
        super(name);
    }
}

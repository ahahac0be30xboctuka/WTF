package StoryWorld.Inanimate.Interfaces;

public interface LeavesActions {
    void yellowed();

    void withered();

    void fall();
}

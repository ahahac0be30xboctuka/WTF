package StoryWorld.Inanimate.Interfaces;
public interface IndianSummerActions {
    void come();
    void pass();
}

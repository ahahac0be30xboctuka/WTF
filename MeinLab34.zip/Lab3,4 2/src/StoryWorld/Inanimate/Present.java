package StoryWorld.Inanimate;

public class Present extends InanimateObjects {

    public Present(String name) {
        super(name);
    }
}
